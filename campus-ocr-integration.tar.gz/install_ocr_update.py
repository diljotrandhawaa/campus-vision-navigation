#!/usr/bin/env python3
"""Install this reviewed update, backing up changed files outside the project."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
from datetime import datetime, timezone


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('project', help='Path to your existing live-yolo-webui folder')
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    project = Path(args.project).expanduser().resolve()
    if package == project:
        raise SystemExit('Extract the update into a separate folder first; see OCR_SETUP.md.')
    manifest = json.loads((package / 'ocr-update-manifest.json').read_text())
    conflicts, changes = [], []
    for relative, info in manifest.items():
        source, target = package / relative, project / relative
        if digest(source) != info['new']:
            raise SystemExit(f'Update package is incomplete or modified: {relative}')
        if target.is_symlink():
            conflicts.append(relative + ' (symlink)'); continue
        # Avoid traversing symlinked directories when installing files.
        if any(parent.is_symlink() for parent in target.parents if parent != project and project in parent.parents):
            conflicts.append(relative + ' (symlinked parent)'); continue
        if target.exists() and not target.is_file():
            conflicts.append(relative + ' (not a file)'); continue
        current = digest(target) if target.exists() else None
        if current == info['new']:
            continue
        if current != info['old']:
            conflicts.append(relative); continue
        changes.append((relative, source, target))
    if conflicts:
        raise SystemExit('No files changed. These files differ from the uploaded version:\n' +
                         '\n'.join(conflicts) + '\nSend the current copies for an updated patch.')
    if not changes:
        print('This OCR update is already installed.'); return
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    backup = project.parent / 'campus-ocr-backups' / stamp
    backup.mkdir(parents=True, exist_ok=False)
    record = {'project': str(project), 'existing': [], 'added': []}
    for relative, source, target in changes:
        if target.exists():
            copy = backup / relative
            copy.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, copy)
            record['existing'].append(relative)
        else:
            record['added'].append(relative)
    (backup / 'backup-info.json').write_text(json.dumps(record, indent=2))
    try:
        for relative, source, target in changes:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    except Exception:
        for relative in record['existing']:
            shutil.copy2(backup / relative, project / relative)
        for relative in record['added']:
            (project / relative).unlink(missing_ok=True)
        raise
    print(f'Installed {len(changes)} files. Backup: {backup}')
    print('Start: python run_yolo.py --port 8091 --http --weights yoloe-26l-seg.pt --imgsz 640 --device 0')
    print('YOLO only: add --no-ocr')


if __name__ == '__main__': main()
